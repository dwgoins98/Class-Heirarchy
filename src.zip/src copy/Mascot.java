
public interface Mascot {
	
	public void setMascot(String mascotName);
	
	public String getMascot();

}
