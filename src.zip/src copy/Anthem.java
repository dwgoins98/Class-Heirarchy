
public interface Anthem {
	
	public void setAnthem(String anthem);
	
	public String getAnthem();
	

}
